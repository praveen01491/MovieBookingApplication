package com.MovieBookingApplication.Model;

public class Movie {

	int id;
	String title;
	String image_url;
	String language;
	String duration;
	
	public Movie() {
		super();
	}
	public Movie(String title,  String language, String duration,String image_url) {
		super();
		this.title = title;
		this.image_url = image_url;
		this.language = language;
		this.duration = duration;
	}
	public int  getId() {
		return id;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getImage_url() {
		return image_url;
	}
	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public void setId(int id) {
		this.id=id;
	}
}
