package com.MovieBookingApplication.Model;

public class UpcomingMovie {
    private int id;
    private String iframeLink;
    private String movieName;
    private String duration;
    private String language;

    // Constructors
    public UpcomingMovie() {}

    public UpcomingMovie(int id, String iframeLink, String movieName, String duration, String language) {
        this.id = id;
        this.iframeLink = iframeLink;
        this.movieName = movieName;
        this.duration = duration;
        this.language = language;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getIframeLink() { return iframeLink; }
    public void setIframeLink(String iframeLink) { this.iframeLink = iframeLink; }

    public String getMovieName() { return movieName; }
    public void setMovieName(String movieName) { this.movieName = movieName; }

    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
}

