package com.MovieBookingApplication.DAO;

import com.MovieBookingApplication.Connection.DBConnection;
import com.MovieBookingApplication.Model.Movie;
import com.MovieBookingApplication.Model.UpcomingMovie;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MovieDAO {

    private Connection conn;

    public MovieDAO() throws SQLException, ClassNotFoundException {
        this.conn = DBConnection.getConnection();
    }
  

    // Add new movie
    public boolean addMovie(Movie movie) throws SQLException {
        String sql = "INSERT INTO movies (title, duration, language, image_url) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, movie.getTitle());
            pstmt.setString(2, movie.getDuration());
            pstmt.setString(3, movie.getLanguage());
            pstmt.setString(4, movie.getImage_url());
            return pstmt.executeUpdate() > 0;
        }
    }

    // Update movie
    public boolean updateMovie(Movie movie) throws SQLException {
        String sql = "UPDATE movies SET title = ?, duration = ?, language = ?, image_url = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, movie.getTitle());
            pstmt.setString(2, movie.getDuration());
            pstmt.setString(3, movie.getLanguage());
            pstmt.setString(4, movie.getImage_url());
            pstmt.setInt(5, movie.getId());
            return pstmt.executeUpdate() > 0;
        }
    }

    // Delete movie
    public boolean deleteMovie(int movieId) throws SQLException {
        String sql = "DELETE FROM movies WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, movieId);
            return pstmt.executeUpdate() > 0;
        }
    }

    // Get movie by ID
    public Movie getMovieById(int id) throws SQLException {
    	System.out.println("method loki vachesam");
        Movie movie = null;
        String sql = "SELECT * FROM movies WHERE id = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, id);
        ResultSet rs = statement.executeQuery();

        if (rs.next()) {
            movie = new Movie();
            movie.setId(rs.getInt("id"));
            movie.setTitle(rs.getString("title"));
            System.out.println(rs.getString("title"));
            movie.setDuration(rs.getString("duration"));
            movie.setLanguage(rs.getString("language"));
            movie.setImage_url(rs.getString("image_url"));
        }
        return movie;
    }

    // Get all movies
    public List<Movie> getAllMovies() throws SQLException {
        List<Movie> movies = new ArrayList<>();
        
        String sql = "SELECT * FROM movies";
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
        	
            while (rs.next()) {
            	
                Movie movie = new Movie();
                movie.setId(rs.getInt("id"));  
                movie.setTitle(rs.getString("title"));
                System.out.println(rs.getString("title"));
                movie.setDuration(rs.getString("duration"));
                movie.setLanguage(rs.getString("language"));
                movie.setImage_url(rs.getString("image_url"));
                movies.add(movie);
            }
        }
        return movies;
    }

    // Search by name
    public List<Movie> searchMoviesByName(String keyword) throws SQLException {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM movies WHERE title LIKE ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + keyword + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Movie movie = new Movie();
                movie.setTitle(rs.getString("title"));
                movie.setDuration(rs.getString("duration"));
                movie.setLanguage(rs.getString("language"));
                movie.setImage_url(rs.getString("image_url"));
                movies.add(movie);
            }
        }
        return movies;
    }
    
    
 // New method to fetch movies by language
    public List<Movie> getMoviesByLanguage(String language) throws SQLException {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM movies WHERE language = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, language);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Movie movie = new Movie();
                movie.setId(rs.getInt("id"));
                movie.setTitle(rs.getString("title"));
                movie.setDuration(rs.getString("duration"));
                movie.setLanguage(rs.getString("language"));
                movie.setImage_url(rs.getString("image_url"));
                movies.add(movie);
            }
        }
        return movies;
    }
    
    
    
    public List<UpcomingMovie> getAllUpcomingMovies() {
        List<UpcomingMovie> list = new ArrayList<>();
        String sql = "SELECT * FROM upcoming_movies";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                UpcomingMovie movie = new UpcomingMovie();
                movie.setId(rs.getInt("id"));
                movie.setIframeLink(rs.getString("iframe_link"));
                movie.setMovieName(rs.getString("movie_name"));
                movie.setDuration(rs.getString("duration"));
                movie.setLanguage(rs.getString("language"));
                list.add(movie);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
    
    
    
 // Add new UpcomingMovie to the database
    public boolean addUpcomingMovie(UpcomingMovie movie) throws SQLException {
        String sql = "INSERT INTO upcoming_movies (movie_name, iframe_link, language, duration) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, movie.getMovieName());
            pstmt.setString(2, movie.getIframeLink());
            pstmt.setString(3, movie.getLanguage());
            pstmt.setString(4, movie.getDuration());
            return pstmt.executeUpdate() > 0;
        }
    }
    
    
    // Delete movie
    public boolean deleteUpcomingMovie(int movieId) throws SQLException {
        String sql = "DELETE FROM upcoming_movies WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, movieId);
            return pstmt.executeUpdate() > 0;
        }
    }

    
    
    
    
    
    
    
    
    
    public List<Map<String, Object>> getTicketsByUsername(String username) throws SQLException {
        List<Map<String, Object>> tickets = new ArrayList<>();
        String sql = "SELECT u.movieid, m.title AS movie, u.date, u.time, u.num_tickets, u.total_price " +
        		"FROM booking_details u JOIN movies m ON u.movie_id = m.id WHERE u.username = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Map<String, Object> ticket = new HashMap<>();
                ticket.put("movieid", rs.getInt("movieid"));            // ✅ Corrected
                ticket.put("movie", rs.getString("movie"));             // ✅ Corrected
                ticket.put("date", rs.getDate("date"));
                ticket.put("time", rs.getString("time"));
                ticket.put("no_of_tickets", rs.getInt("num_tickets"));
                ticket.put("price", rs.getDouble("total_price"));
                tickets.add(ticket);
            }
        }

        return tickets;
    }

    public void cancelTicket(int movieid, String username) throws SQLException {
        String sql = "DELETE FROM UserDetails WHERE movieid=? AND username=?";
        try ( PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, movieid);
            stmt.setString(2, username);
            stmt.executeUpdate();
        }
    }
}
