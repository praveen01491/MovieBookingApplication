package com.MovieBookingApplication.DAO;

import com.MovieBookingApplication.Connection.DBConnection;
import com.MovieBookingApplication.Model.User;

import java.sql.*;
import java.util.*;

public class UserDAO {

    private Connection conn;

    public UserDAO() throws SQLException, ClassNotFoundException {
        this.conn = DBConnection.getConnection();
    }

    public boolean addUser(User user) throws SQLException {
        String sql = "INSERT INTO UserDetails (user_email, user_password, user_name) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, user.getEmail());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getName());
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean updateUser(User user) throws SQLException {
        String sql = "UPDATE UserDetails SET user_email = ?, user_password = ?, user_name = ? WHERE user_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, user.getEmail());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getName());
            pstmt.setInt(4, user.getId());
            return pstmt.executeUpdate() > 0;
        }
    }

    public boolean deleteUser(int userId) throws SQLException {
        String sql = "DELETE FROM UserDetails WHERE user_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            return pstmt.executeUpdate() > 0;
        }
    }

    public User getUserById(int userId) throws SQLException {
        String sql = "SELECT * FROM UserDetails WHERE user_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("user_id"));
                user.setEmail(rs.getString("user_email"));
                user.setPassword(rs.getString("user_password"));
                user.setName(rs.getString("user_name"));
                return user;
            }
        }
        return null;
    }

    public List<User> getAllUsers() throws SQLException {
    	System.out.println("method loki vachesnam");
        List<User> userList = new ArrayList<>();
        String sql = "SELECT * FROM UserDetails";
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("user_id"));
                user.setEmail(rs.getString("user_email"));
                user.setPassword(rs.getString("user_password"));
                user.setName(rs.getString("user_name"));
                userList.add(user);
            }
        }
        return userList;
    }

    public User getUserByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM UserDetails WHERE user_email = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("user_id"));
                user.setEmail(rs.getString("user_email"));
                user.setPassword(rs.getString("user_password"));
                user.setName(rs.getString("user_name"));
                return user;
            }
        }
        return null;
    }
}
