package com.MovieBookingApplication.Servlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Servlet implementation class RoutingServlet
 */
@WebServlet("/Routing")
public class RoutingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public RoutingServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 
		String user_email=request.getParameter("email");
		String user_password=request.getParameter("password");
		String user_name=request.getParameter("username");
		if("praveen@gmail.com".equals(user_email) && "123".equals(user_password)) {
		    request.getRequestDispatcher("adminPage.jsp").forward(request, response);
		    return; // important to avoid running rest of the method
		}
				request.setAttribute("username", user_name);
		 
		 String jdbcURL = "jdbc:mysql://localhost:3306/BookingApplication";
         String dbUser = "root";        
         String dbPassword = "root";  

         String SelectSQL = "SELECT * FROM UserDetails WHERE (user_name = ? OR user_email = ?) AND user_password = ?";
                 
         
         boolean validUser=false;
         String username="";
         try {
             Class.forName("com.mysql.cj.jdbc.Driver");

             // Establish connection
             Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
             PreparedStatement pstmt = conn.prepareStatement(SelectSQL);
             pstmt.setString(1, user_name);
             pstmt.setString(2, user_email);
             pstmt.setString(3, user_password);

             ResultSet rs = pstmt.executeQuery();
             
   
             
             if(rs.next()) {
            	 username=rs.getString("user_name");
            	 validUser=true;
             }

   
             conn.close();

         } catch (Exception e) {
             throw new ServletException("DB Error: " + e.getMessage());
         }
         
         if (validUser) {

        	 
        	 
        	 System.out.println("Logged in user: " + username);
        	 request.getSession().setAttribute("username", username);
        	 response.sendRedirect("fetchMovies"); // call MovieServlet 

         } else {
             request.setAttribute("errorMessage", "Invalid email or password.");
             request.getRequestDispatcher("badCredentials.jsp").forward(request, response); // login failed
         }
		 

		 
		 
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
