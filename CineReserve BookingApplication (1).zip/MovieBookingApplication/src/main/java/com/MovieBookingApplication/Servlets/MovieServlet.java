package com.MovieBookingApplication.Servlets;

import com.MovieBookingApplication.DAO.MovieDAO;
import com.MovieBookingApplication.Model.Movie;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/userHome")
public class MovieServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            MovieDAO movieDAO = new MovieDAO();

            List<Movie> teluguMovies = movieDAO.getMoviesByLanguage("telugu");
            List<Movie> englishMovies = movieDAO.getMoviesByLanguage("english");
            List<Movie> malayalamMovies = movieDAO.getMoviesByLanguage("malayalam");
            List<Movie> tamilMovies = movieDAO.getMoviesByLanguage("tamil");
            List<Movie> kannadaMovies = movieDAO.getMoviesByLanguage("kannada");
            
            for(Movie m:englishMovies) {
            	System.out.println(m.getTitle());
            }

            request.setAttribute("telugu_movies", teluguMovies);
            request.setAttribute("english_movies", englishMovies);
            request.setAttribute("malayalam_movies", malayalamMovies);
            request.setAttribute("tamil_movies", tamilMovies);
            request.setAttribute("kannada_movies", kannadaMovies);

            request.getRequestDispatcher("userPage.jsp").forward(request, response);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Database connection or query failed.");
        }
    }
}
