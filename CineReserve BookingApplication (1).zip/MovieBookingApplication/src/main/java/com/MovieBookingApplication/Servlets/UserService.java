package com.MovieBookingApplication.Servlets;

import com.MovieBookingApplication.DAO.UserDAO;
import com.MovieBookingApplication.Model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

//@WebServlet("/UserService")
public class UserService extends HttpServlet {
    private static final long serialVersionUID = 1L;
    UserDAO userDao;

    public void init() throws ServletException {
        try {
            userDao = new UserDAO();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new ServletException("UserDAO init failed", e);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                userDao.deleteUser(id);
                response.sendRedirect("UserService?action=view&message=Deleted+successfully");
            } 
            else if ("edit".equals(action)) {
            	System.out.println("ikadiki vachinam");
                int id = Integer.parseInt(request.getParameter("id"));
                User user = userDao.getUserById(id);
                if (user == null) {
                    response.sendRedirect("UserService?action=view&message=User+not+found");
                    return;
                }
                request.setAttribute("user", user);
                request.getRequestDispatcher("editUser.jsp").forward(request, response);
            } 
            else if ("view".equals(action)) {
            	System.out.println("view action ok workling");
                List<User> users = userDao.getAllUsers();
                request.setAttribute("users", users);
                request.getRequestDispatcher("users.jsp").forward(request, response);
            } 
            else {
                response.sendRedirect("UserService?action=view");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if ("add".equals(action)) {
            	System.out.println("akdsvgh");
                User user = new User();
                user.setName(request.getParameter("name"));
                user.setEmail(request.getParameter("email"));
                user.setPassword(request.getParameter("password"));
                userDao.addUser(user);
                response.sendRedirect("UserService?action=view&message=Added+successfully");

            } else if ("update".equals(action)) {
                User user = new User();
                user.setId(Integer.parseInt(request.getParameter("user_id")));
                user.setName(request.getParameter("user_name"));
                user.setEmail(request.getParameter("user_email"));
                user.setPassword(request.getParameter("user_password"));
                userDao.updateUser(user);
                response.sendRedirect("UserService?action=view&message=Updated+successfully");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
