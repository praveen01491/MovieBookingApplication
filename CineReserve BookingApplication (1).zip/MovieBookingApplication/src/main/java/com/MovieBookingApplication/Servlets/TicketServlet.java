package com.MovieBookingApplication.Servlets;

import com.MovieBookingApplication.DAO.MovieDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/TicketServlet")
public class TicketServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = (String) request.getSession().getAttribute("username");
        System.out.println("username");
        if (username == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        try {
            MovieDAO movieDAO = new MovieDAO(); // ✅ now inside try block
            List<Map<String, Object>> tickets = movieDAO.getTicketsByUsername(username);
            System.out.println("asdfghjkl");
            request.setAttribute("tickets", tickets);
            request.getRequestDispatcher("userTicket.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error fetching tickets: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("cancel".equals(action)) {
            int movieId = Integer.parseInt(request.getParameter("movieid"));
            String username = (String) request.getSession().getAttribute("username");

            try {
                MovieDAO movieDAO = new MovieDAO(); // ✅ instantiate here
                movieDAO.cancelTicket(movieId, username);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        response.sendRedirect("TicketServlet"); // Refresh ticket list after cancellation
    }
}


