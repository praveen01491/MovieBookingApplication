package com.MovieBookingApplication.Servlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;



@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    		
    	String username=request.getParameter("username");
    	String email=request.getParameter("email");
    	String password=request.getParameter("password");
    	String back=request.getParameter("back to login");
    	
    	
    	
    	
    	
    	
    	 String jdbcURL = "jdbc:mysql://localhost:3306/BookingApplication";
         String dbUser = "root";         // change as needed
         String dbPassword = "root";  // change as needed

         String insertSQL = "INSERT INTO userDetails (user_name, user_email, user_password) VALUES (?, ?, ?)";

         try {
             // Load JDBC Driver (optional in newer versions)
             Class.forName("com.mysql.cj.jdbc.Driver");

             // Establish connection
             Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
             PreparedStatement stmt = conn.prepareStatement(insertSQL);

             // Set parameters
             stmt.setString(1, username);
             stmt.setString(2, email);
             stmt.setString(3, password);

             int rowsInserted = stmt.executeUpdate();



//             if (rowsInserted > 0) {
//                 out.println("<h3>Registration Successful!</h3>");
//             } else {
//                 out.println("<h3>Registration Failed. Try again!</h3>");
//             }

             conn.close();

         } catch (Exception e) {
             throw new ServletException("DB Error: " + e.getMessage());
         }
    	
    	
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("RegistrationDone.jsp");
        dispatcher.forward(request, response);
        
        
        
        
    }
}
