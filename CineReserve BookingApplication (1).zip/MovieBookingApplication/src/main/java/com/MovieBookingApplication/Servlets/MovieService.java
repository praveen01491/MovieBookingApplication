package com.MovieBookingApplication.Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.MovieBookingApplication.DAO.MovieDAO;
import com.MovieBookingApplication.Model.Movie;
import com.MovieBookingApplication.Model.UpcomingMovie;

//@WebServlet("/MovieService")
public class MovieService extends HttpServlet {
    private static final long serialVersionUID = 1L;
    MovieDAO movieDao;

    public void init() throws ServletException {
        try {
            movieDao = new MovieDAO();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new ServletException("DAO init failed", e);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                movieDao.deleteMovie(id);
                response.sendRedirect("MovieService?action=view&message=Deleted+successfully");

            }
            else if ("deleteUpcomingMovie".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                movieDao.deleteUpcomingMovie(id);
                response.sendRedirect("MovieService?action=view&message=Deleted+successfully");

            } else if ("edit".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                Movie movie = movieDao.getMovieById(id);
                if (movie == null) {
                    response.sendRedirect("MovieService?action=view&message=Movie+not+found");
                    return;
                }
                request.setAttribute("movie", movie);
                request.getRequestDispatcher("editMovie.jsp").forward(request, response);

            } else if ("view".equals(action)) {
                List<Movie> movies = movieDao.getAllMovies();
                request.setAttribute("movies", movies);
                request.getRequestDispatcher("movies.jsp").forward(request, response);

            } else {
                response.sendRedirect("MovieService?action=view");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if ("add".equals(action)) {
                Movie movie = new Movie();
                movie.setTitle(request.getParameter("title"));
                movie.setDuration(request.getParameter("duration"));
                movie.setLanguage(request.getParameter("language"));
                movie.setImage_url(request.getParameter("image_url"));
                movieDao.addMovie(movie);
                response.sendRedirect("MovieService?action=view&message=Added+successfully");

            } else if ("update".equals(action)) {
                Movie movie = new Movie();
                movie.setId(Integer.parseInt(request.getParameter("id")));
                movie.setTitle(request.getParameter("title"));
                movie.setDuration(request.getParameter("duration"));
                movie.setLanguage(request.getParameter("language"));
                movie.setImage_url(request.getParameter("image_url"));
                movieDao.updateMovie(movie);
                response.sendRedirect("MovieService?action=view&message=Updated+successfully");

            } else if ("addUpcomingMovie".equals(action)) {
                UpcomingMovie movie = new UpcomingMovie();
                movie.setMovieName(request.getParameter("MovieName")); // name of the movie
                movie.setDuration(request.getParameter("duration"));
                movie.setLanguage(request.getParameter("language"));
                movie.setIframeLink(request.getParameter("iframe_link")); // iframe_link
                movieDao.addUpcomingMovie(movie); // Call correct method
                response.sendRedirect("MovieService?action=view&message=Upcoming+movie+added+successfully");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
