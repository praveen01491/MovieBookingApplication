package com.MovieBookingApplication.Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

import com.MovieBookingApplication.DAO.MovieDAO;
import com.MovieBookingApplication.Model.Movie;

//@WebServlet("/searchMovies")
public class searchMovies extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public searchMovies() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String query = request.getParameter("query");

        try {
            MovieDAO movieDao = new MovieDAO(); // Create DAO in try block
            List<Movie> movies = movieDao.searchMoviesByName(query); // Call DAO method

            request.setAttribute("movies", movies); // Attach result to request
            request.getRequestDispatcher("searchResults.jsp").forward(request, response); // Forward to JSP

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error occurred while searching movies: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
