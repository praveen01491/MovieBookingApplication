package com.MovieBookingApplication.Servlets;

import java.io.IOException;
import java.sql.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BookingServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String movieIdStr = request.getParameter("movieId");
        String movieName = request.getParameter("movieName");
        String duration = request.getParameter("Duration");
        String date = request.getParameter("date");
        String time = request.getParameter("time");
        String numTicketsStr = request.getParameter("numTickets");

        int movieId = Integer.parseInt(movieIdStr);
        int numTickets = Integer.parseInt(numTicketsStr);
        int pricePerTicket = 150;
        int totalPrice = pricePerTicket * numTickets;

        String url = "jdbc:mysql://localhost:3306/BookingApplication";
        String dbUsername = "root";
        String dbPassword = "root";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword);

            String checkSql = "SELECT SUM(num_tickets) AS total_booked FROM booking_details WHERE movie_id = ? AND date = ? AND time = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, movieId);
            checkStmt.setString(2, date);
            checkStmt.setString(3, time);

            ResultSet rs = checkStmt.executeQuery();

            int totalBooked = 0;
            if (rs.next()) {
                totalBooked = rs.getInt("total_booked");
            }

            if (totalBooked + numTickets > 60) {
                request.setAttribute("movieId", movieId);
                request.setAttribute("movieName", movieName);
                request.setAttribute("bookingDate", date);
                request.setAttribute("bookingTime", time);

                // ✅ Forward to a servlet that repopulates movie list
                RequestDispatcher dispatcher = request.getRequestDispatcher("seatsunavailable.jsp");
                dispatcher.forward(request, response);
                return;
            }

            // Insert booking
            String insertSQL = "INSERT INTO booking_details (username, movie_id, movie_name, date, time, num_tickets, total_price) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertSQL);
            insertStmt.setString(1, username);
            insertStmt.setInt(2, movieId);
            insertStmt.setString(3, movieName);
            insertStmt.setString(4, date);
            insertStmt.setString(5, time);
            insertStmt.setInt(6, numTickets);
            insertStmt.setInt(7, totalPrice);
            insertStmt.executeUpdate();

            conn.close();

            request.setAttribute("username", username);
            request.setAttribute("movieId", movieId);
            request.setAttribute("movieName", movieName);
            request.setAttribute("Duration", duration);
            request.setAttribute("date", date);
            request.setAttribute("time", time);
            request.setAttribute("numTickets", numTickets);
            request.setAttribute("totalPrice", totalPrice);

            RequestDispatcher rd = request.getRequestDispatcher("bookingconfirmation.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
