package com.MovieBookingApplication.Servlets;



//@WebServlet("/AdminServlet")

import java.io.IOException;
import java.util.List;

import com.MovieBookingApplication.DAO.MovieDAO;
import com.MovieBookingApplication.DAO.UserDAO;
import com.MovieBookingApplication.Model.Movie;
import com.MovieBookingApplication.Model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AdminServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	try {
            
            
            
            String view = request.getParameter("view");

            if ("movies".equals(view)) {
            	MovieDAO movieDAO = new MovieDAO();
                List<Movie> movies = movieDAO.getAllMovies();
                request.setAttribute("movies", movies);

                request.getRequestDispatcher("movies.jsp").forward(request, response);

            } else if ("users".equals(view)) {
            	UserDAO userDAO=new UserDAO();
                List<User> users=userDAO.getAllUsers();
                request.setAttribute("users",users);
                request.getRequestDispatcher("users.jsp").forward(request, response);

            } else {
                // Default or dashboard
                request.getRequestDispatcher("adminPage.jsp").forward(request, response);
            }
            
        } catch (Exception e) {
            throw new ServletException("DB Error: " + e.getMessage());
        }
    }
}